# Changelog

All notable changes to `@magic-ingredients/no-tickets-schemas` are documented here.

The format is based on [Keep a Changelog](https://keepachangelog.com/), and this
package adheres to [Semantic Versioning](https://semver.org/) — see
`PUBLISHING.md` for the bump policy specific to schema changes.

## [Unreleased]

## [0.1.0] - Initial public surface

### Added
- `byTypeId` runtime lookup table mapping canonical type ids to their Zod schemas.
- `EventTypeId` exported union of canonical type ids.
- `ai.completion.recorded.v1`, `ai.review.completed.v1`, `ai.task.completed.v1` schemas
  with associated enums (`PROVIDERS`, `STOP_REASONS`, `TASK_OUTCOMES`,
  `REVIEW_SOURCES`, `REVIEW_GRADES`, `KNOWN_REVIEWERS`) and severity helpers.
- `product.epic.created.v1`, `product.feature.created.v1`,
  `product.feature.status_changed.v1`, `product.feature.assigned.v1`,
  `product.feature.archived.v1`, `product.task.created.v1`,
  `product.task.status_changed.v1`, `product.task.assigned.v1` schemas.
- Shared product enums (`PRODUCT_STATUSES`, `PRODUCT_ASSIGNEE_TYPES`).
- Dedupe-key formatters for `feature.status_changed` and `task.status_changed`.
